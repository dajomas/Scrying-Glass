# Further split of Scrying Glass

## Installation

Back up the working application. Extract all Python files in this archive into
its existing application directory, beside the existing helper modules, HTML
modules, and static directory. Replace only scrying_glass_server.py and
scrying_glass_api_admin.py. The other 19 Python files are new.

Keep the existing, corrected scrying_glass_api_client.py, scrying_glass_init.py,
scrying_glass_hp.py, scrying_glass_combatant.py, scrying_glass_tools.py,
scrying_glass_monster_csv.py, scrying_glass_dndbeyond.py, and
scrying_glass_classes.py. They are intentionally not included: project copies
may predate your latest fixes.

Run using the same command and configuration as before:

    python3.14 scrying_glass_server.py --config config.yaml

This remains a flat module layout, not a new Python package. Keep static assets
beside the main server. Configuration and storage startup remain in the direct
script entry point; externally importing it with uvicorn is not a supported
replacement for the documented launch command.

## Service split

Nine service classes group authentication, encounter state, campaigns, storage
migration, persistence, activity logging, images, battle management, and change
notifications. scrying_glass_services.py binds their methods onto the live
server context before constructing APIs or initializing storage.

The main server remains the sole owner of mutable runtime state. Services use
self.context.STATE, self.context.CONFIG, and context storage paths, including
when they reassign these values. They never import the main server and never
maintain private snapshots of those objects. Existing APIs continue using the
same context method names. Startup and static mounts remain in the server.

## Admin API split

Nine mixins group pages, display, setups, campaigns, monsters, characters,
shared combatants, battle actions, and activity logging. AdminAPI composes them
and registers a compact manifest of the original 41 admin routes. Paths,
handler names, registration order, HTTP methods, and authentication requirements
are preserved. Handler annotations are still resolved using the server context.

## Validation and limitations

All 21 Python files pass syntax compilation in the available Python environment.
AST comparisons verify all 56 extracted service function bodies after reversing
the context transformation and removing global declarations. All 41 admin
handler methods are unchanged. Multiline string values, including regexes,
were preserved exactly during service extraction.

FastAPI and the latest corrected helper files are not installed in the execution
environment. A full import, HTTP, WebSocket, and server-startup test was not run.
This is an organization-only refactor; existing unrelated behavior is preserved.

Before replacing production, test login on both ports; create/save/load/delete
setups; activate campaigns; create/import/edit/reset/delete combatants; run
battle turns/actions; export the activity log; verify display WebSocket updates;
and restart to verify setup and campaign roster persistence.
