# Split admin HTML

Replace the existing admin_html.py with the supplied loader, and copy the
complete templates/admin directory beside it. Keep existing static/admin.css
and static/admin.js unchanged. No server, API, client, or dependency changes
are required. Preserve your existing authentication route; these fragments
are trusted local inputs assembled by the server, not browser-fetched files.

The loader exports ADMIN_HTML exactly as before and reads 20 UTF-8 fragments
once at module import. Restart the server after edits. If a fragment is missing,
the import raises a file-read error instead of serving an incomplete page.
Paths resolve relative to admin_html.py, not the shell working directory.

The explicitly ordered fragments group document framing, pane controls,
battle controls, campaign/character/setup/monster input, character/monster
display, activity logging, and individual dialogs. They are document fragments,
not independent HTML documents. Keep their assembly order. The monster display
fragment also closes the main element, as it does in the original document.

Validation: the loader was executed using the Python standard library, and its
ADMIN_HTML output was compared with the uploaded original Python string. They
are exactly equal, including whitespace, IDs, attributes, script/style links,
and Unicode text. No browser or full-server test was performed.

This archive contains only the replacement loader, fragments, and these notes.
Do not expose the templates directory through a static mount unless you
explicitly intend to make its source public. Include templates/admin in future
application deployment or packaging steps.
